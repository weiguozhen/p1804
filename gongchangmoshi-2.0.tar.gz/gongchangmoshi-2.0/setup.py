from distutils.core import setup
setup(name="gongchangmoshi", version="2.0", description="gongchangmoshi", author="weibaba", py_modules=['suba.gongchang', 'suba.gongchang1', 'suba.gongchang2'])
