class YilanteCar(object):
    def move(self):
        print("车载移动")
    def stop(self):
        print("停车")
class SuonataCar(object):
    def move(self):
        print("车在移动")
    def stop(self):
        print("停车")
class CarFactory(object):
    def createCar(self,typeName):
        if typeName=="伊兰特":
            car=YilanteCar()
        elif typeName=="索纳塔":
            car=SuonataCar()
        return car
class CarStore(object):
    def __init__(self):
        self.carFactory=CarFactory()
    def order(self,typeName):
        Car=self.carFactory.createCar(typename)
        return car
